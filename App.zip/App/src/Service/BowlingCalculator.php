<?php

namespace App\Service;

use App\Struct\FrameResultStruct;

class BowlingCalculator
{

    public function __construct()
    {
    }

    public function calculateResult(array $resultArray): array
    {
        foreach($resultArray as $key => &$result) {
            $frameResult = FrameResultStruct::createWithArray($result);
            $result['result'] = $frameResult->setResult($result['firstTry'] + $result['secondTry']);

            if($key - 1 > 0 ) {
                $previousResult = $resultArray[$key - 1]['result']->getResult();
                $frameResult->setResult($previousResult + $frameResult->getResult());
            }
        }

        return $resultArray;
    }
}