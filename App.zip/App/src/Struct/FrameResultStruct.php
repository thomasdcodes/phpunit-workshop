<?php

declare(strict_types=1);

namespace App\Struct;

use function PHPUnit\Framework\isNull;

class FrameResultStruct
{
    private ?int $firstTry = null;
    private ?int $secondTry = null;
    private ?int $thirdTry = null;
    private ?int $result = null;

    public static function createWithArray(array $dataArray): FrameResultStruct
    {
        return (new FrameResultStruct())
            ->setFirstTry($dataArray['firstTry'])
            ->setSecondTry($dataArray['secondTry'])
            ->setThirdTry($dataArray['thirdTry']);
    }

    public function getFirstTry(): ?int
    {
        return $this->firstTry;
    }

    public function setFirstTry(int $firstTry): FrameResultStruct
    {
        $this->validateTry($firstTry);
        $this->firstTry = $firstTry;
        return $this;
    }

    public function getSecondTry(): ?int
    {
        return $this->secondTry;
    }

    public function setSecondTry(?int $secondTry): FrameResultStruct
    {
        if(!isNull($secondTry))
            $this->validateTry($secondTry);
        $this->secondTry = $secondTry;
        return $this;
    }

    public function getThirdTry(): ?int
    {
        return $this->thirdTry;
    }

    public function setThirdTry(?int $thirdTry): FrameResultStruct
    {
        if(!isNull($thirdTry))
            $this->validateTry($thirdTry);
        $this->thirdTry = $thirdTry;
        return $this;
    }

    public function getResult(): ?int
    {
        return $this->result;
    }

    public function setResult(?int $result): FrameResultStruct
    {
        $this->result = $result;
        return $this;
    }

    /**
     * @param int $firstTry
     * @return void
     */
    public function validateTry(int $firstTry): void
    {
        if ($firstTry < 0 || $firstTry > 10) {
            throw new \InvalidArgumentException("firstTry must be between 0 and 10");
        }
    }
}