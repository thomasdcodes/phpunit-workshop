<?php

include '../vendor/autoload.php';

$test = 'Test';

echo 'TEST';