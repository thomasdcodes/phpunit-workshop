<?php

namespace Struct;

use App\Struct\FrameResultStruct;
use PHPUnit\Framework\Attributes\TestWith;
use PHPUnit\Framework\TestCase;

class FrameResultStructTest extends TestCase
{
    public function testConstructor(): void
    {
        $frameResultStruct = new FrameResultStruct();

        $this->assertInstanceOf(FrameResultStruct::class, $frameResultStruct);
    }

    public function testSetAndGetFirstTry(): void
    {
        $frameResultStruct = new FrameResultStruct();

        $frameResultStruct->setFirstTry(8);

        $this->assertEquals(8, $frameResultStruct->getFirstTry());
    }

    #[TestWith([11])]
    #[TestWith([-1])]
    public function testCanNotSetFirstTryWithInvalidValue($valueToSet): void
    {
        // Arrange
        $frameResultStruct = new FrameResultStruct();

        // Except
        $this->expectException(\InvalidArgumentException::class);

        // Act
        $frameResultStruct->setFirstTry($valueToSet);
    }

    public function testSetAndGetSecondTry(): void
    {
        $frameResultStruct = new FrameResultStruct();

        $frameResultStruct->setSecondTry(4);

        $this->assertEquals(4, $frameResultStruct->getSecondTry());
    }

    public function testSetAndGetThirdTry(): void
    {
        $frameResultStruct = new FrameResultStruct();

        $frameResultStruct->setThirdTry(0);

        $this->assertEquals(0, $frameResultStruct->getThirdTry());
    }

    public function testSetAndGetResultTry(): void
    {
        $frameResultStruct = new FrameResultStruct();

        $frameResultStruct->setResult(8);

        $this->assertEquals(8, $frameResultStruct->getResult());
    }

    public function testFactoryMethodWithArray(): void
    {
        $dataArray = [
            'firstTry' => 8,
            'secondTry' => 4,
            'thirdTry' => 0,
        ];
        $frameResultStruct = FrameResultStruct::createWithArray($dataArray);

        $this->assertEquals(8, $frameResultStruct->getFirstTry());
        $this->assertEquals(4, $frameResultStruct->getSecondTry());
        $this->assertEquals(0, $frameResultStruct->getThirdTry());
    }
}