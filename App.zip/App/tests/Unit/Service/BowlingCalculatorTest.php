<?php

declare(strict_types=1);

use App\Service\BowlingCalculator;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class BowlingCalculatorTest extends TestCase
{
    public static function dataForFirstFrame(): array
    {
        return [
            [
                [
                    1 => [
                        'firstTry' => 3,
                        'secondTry' => 4,
                        'thirdTry' => null,
                        'result' => null,
                        'expectedResult' => 7,
                    ],
                ]
            ],
            [
                [
                    1 => [
                        'firstTry' => 8,
                        'secondTry' => 1,
                        'thirdTry' => null,
                        'result' => null,
                        'expectedResult' => 9,
                    ]
                ]
            ],
            [
                [
                    1 => [
                        'firstTry' => 10,
                        'secondTry' => null,
                        'thirdTry' => null,
                        'result' => null,
                        'expectedResult' => 10,
                    ]
                ]
            ]
        ];
    }

    public function testCanInitService(): void
    {
        // Arrange
        $bowlingCalculator = new BowlingCalculator();

        // Act

        // Assert
        $this->assertInstanceOf(BowlingCalculator::class, $bowlingCalculator);
    }

    #[DataProvider(methodName: 'dataForFirstFrame')]
    public function testCanCalculateResultOfFirstFrame(array $resultArray): void
    {
        $bowlingCalculator = new BowlingCalculator();

        // Act
        $resultArray = $bowlingCalculator->calculateResult($resultArray);

        // Assert
        $this->assertSame($resultArray[1]['expectedResult'], $resultArray[1]['result']->getResult());
    }

    public function testCanCalculateResultOfSecondFrame(): void
    {
        $resultArray = [
            1 => [
                'firstTry' => 7,
                'secondTry' => 2,
                'thirdTry' => null,
                'result' => null,
            ],
            2 => [
                'firstTry' => 2,
                'secondTry' => 1,
                'thirdTry' => null,
                'result' => null,
            ],
        ];

        $bowlingCalculator = new BowlingCalculator();

        // Act
        $resultArray = $bowlingCalculator->calculateResult($resultArray);

        // Assert
        $this->assertSame(12, $resultArray[2]['result']->getResult());
    }

    public function testCanCalculateResultOfThirdFrame(): void
    {
        $resultArray = [
            1 => [
                'firstTry' => 7,
                'secondTry' => 2,
                'thirdTry' => null,
                'result' => null,
            ],
            2 => [
                'firstTry' => 2,
                'secondTry' => 1,
                'thirdTry' => null,
                'result' => null,
            ],
            3 => [
                'firstTry' => 5,
                'secondTry' => 4,
                'thirdTry' => null,
                'result' => null,
            ],
        ];

        $bowlingCalculator = new BowlingCalculator();

        // Act
        $resultArray = $bowlingCalculator->calculateResult($resultArray);

        // Assert
        $this->assertSame(21, $resultArray[3]['result']->getResult());
    }
}